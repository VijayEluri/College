package dataStructure;


public class PositionTableEntry {

    double x;
    double y;

    public void setX (double newx) { x = newx; }

    public void setY (double newy) { y = newy; }

    public double getX() { return x; }

    public double getY() { return y; }

}

