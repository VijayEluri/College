package msc;

public abstract class Item {

	public abstract Node getNode();
	
	public abstract boolean equals(Item i);
}
