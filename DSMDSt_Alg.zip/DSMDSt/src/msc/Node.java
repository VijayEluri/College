package msc;

public class Node {
	int id;
	
	public Node(int vId) {
		id = vId;
	}
	
	public int getId() {
		return id;
	}
}
